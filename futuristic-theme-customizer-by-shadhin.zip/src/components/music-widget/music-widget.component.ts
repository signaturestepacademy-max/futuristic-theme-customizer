import { Component, ChangeDetectionStrategy, input, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ColorPalette } from '../../models/theme.model';
import { WidgetStyle } from '../../app.component';
import { ColorService } from '../../services/color.service';

@Component({
  selector: 'app-music-widget',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (palette(); as p) {
      <div 
        class="w-full h-full p-6 rounded-2xl flex flex-col justify-between transition-all duration-500"
        [style]="widgetStyles()"
        [style.color]="p.text"
      >
        <div>
          <div class="font-orbitron text-2xl font-bold truncate">Cyberdream</div>
          <div class="text-md uppercase tracking-wider" [style.color]="p.secondary">Synthwave Artist</div>
        </div>
        <div class="flex items-center justify-between mt-4">
          <button class="p-2 rounded-full transition-colors" [style.color]="p.secondary" [style.--hover-color]="p.text" hover-class="hover:text-[var(--hover-color)]">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 19l-7-7 7-7m8 14l-7-7 7-7" /></svg>
          </button>
          <button class="p-3 rounded-full transition-colors" [style.background-color]="p.accent" [style.color]="playButtonIconColor()">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd" /></svg>
          </button>
          <button class="p-2 rounded-full transition-colors" [style.color]="p.secondary" [style.--hover-color]="p.text" hover-class="hover:text-[var(--hover-color)]">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg>
          </button>
        </div>
      </div>
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MusicWidgetComponent {
  palette = input.required<ColorPalette | null>();
  style = input<WidgetStyle>('glass');

  private colorService = inject(ColorService);

  playButtonIconColor = computed(() => {
    const p = this.palette();
    if (!p || !p.accent) return '#000000';
    return this.colorService.getContrastColor(p.accent);
  });

  widgetStyles = computed(() => {
    const p = this.palette();
    if (!p) return {};
    
    switch (this.style()) {
      case 'opaque':
        return { backgroundColor: p.background };
      case 'gradient':
        return { backgroundImage: `linear-gradient(to bottom right, ${p.primary}CC, ${p.secondary}CC)` };
      case 'glass':
      default:
        return { 
          backgroundColor: p.background + '80',
          'backdrop-filter': 'blur(10px)',
          '-webkit-backdrop-filter': 'blur(10px)'
        };
    }
  });
}
