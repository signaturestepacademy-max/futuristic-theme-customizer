import { Component, ChangeDetectionStrategy, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ColorPalette, Theme, ThemeRoleMap } from './models/theme.model';
import { ThemeService } from './services/theme.service';
import { GeminiService } from './services/gemini.service';
import { ClockWidgetComponent } from './components/clock-widget/clock-widget.component';
import { WeatherWidgetComponent } from './components/weather-widget/weather-widget.component';
import { MusicWidgetComponent } from './components/music-widget/music-widget.component';
import { CalendarWidgetComponent } from './components/calendar-widget/calendar-widget.component';

export type WidgetStyle = 'glass' | 'opaque' | 'gradient';

declare var JSZip: any;

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    ClockWidgetComponent,
    WeatherWidgetComponent,
    MusicWidgetComponent,
    CalendarWidgetComponent
  ],
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent implements OnInit {
  private themeService = inject(ThemeService);
  private geminiService = inject(GeminiService);

  // Default theme settings
  private defaultPalette: ColorPalette = {
    primary: '#00ffff',
    secondary: '#ff00ff',
    accent: '#ffff00',
    text: '#ffffff',
    background: '#1a1a2e',
  };
  private defaultWallpaper = 'https://picsum.photos/seed/futuristic/1080/1920';
  private defaultThemeMap: ThemeRoleMap = {
    colorPrimary: 'primary',
    colorOnPrimary: 'text',
    colorSecondary: 'secondary',
    colorOnSecondary: 'text',
    colorAccent: 'accent',
    android_colorBackground: 'background',
    colorOnBackground: 'text',
    colorSurface: 'background',
    colorOnSurface: 'text',
  };

  // Component state signals
  wallpaperUrl = signal<string>(this.defaultWallpaper);
  palette = signal<ColorPalette>(this.defaultPalette);
  isLoading = signal(false);
  errorMessage = signal<string | null>(null);
  widgetStyle = signal<WidgetStyle>('glass');
  themeMap = signal<ThemeRoleMap>(this.defaultThemeMap);
  
  readonly paletteKeys: (keyof ColorPalette)[] = ['primary', 'secondary', 'accent', 'text', 'background'];
  readonly widgetStyles: { id: WidgetStyle; name: string }[] = [
    { id: 'glass', name: 'Glassmorphism' },
    { id: 'opaque', name: 'Opaque' },
    { id: 'gradient', name: 'Gradient' },
  ];
  readonly themeRoles: { key: string, name: string }[] = [
    { key: 'colorPrimary', name: 'Primary' },
    { key: 'colorOnPrimary', name: 'On Primary' },
    { key: 'colorSecondary', name: 'Secondary' },
    { key: 'colorOnSecondary', name: 'On Secondary' },
    { key: 'colorAccent', name: 'Accent' },
    { key: 'android_colorBackground', name: 'Background' },
    { key: 'colorOnBackground', name: 'On Background' },
    { key: 'colorSurface', name: 'Surface' },
    { key: 'colorOnSurface', name: 'On Surface' },
  ];

  ngOnInit(): void {
    const savedTheme = this.themeService.loadTheme();
    if (savedTheme) {
      this.wallpaperUrl.set(savedTheme.wallpaperUrl);
      this.palette.set(savedTheme.palette);
      this.themeMap.set(savedTheme.themeMap || this.defaultThemeMap);
    }
  }

  async onFileSelected(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) {
      return;
    }

    const file = input.files[0];
    if (!file.type.startsWith('image/')) {
      this.errorMessage.set('Please select a valid image file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e: any) => {
      this.wallpaperUrl.set(e.target.result);
      this.errorMessage.set(null);
      this.isLoading.set(true);

      try {
        const base64Image = e.target.result.split(',')[1];
        const newPalette = await this.geminiService.extractColorsFromImage(base64Image);
        this.palette.set(newPalette);
      } catch (error: any) {
        this.errorMessage.set(error.message || 'An unknown error occurred.');
      } finally {
        this.isLoading.set(false);
        input.value = '';
      }
    };
    reader.readAsDataURL(file);
  }

  onXmlFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;
    
    const file = input.files[0];
    if (!file.name.endsWith('.xml')) {
      this.errorMessage.set('Please select a valid colors.xml file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e: any) => {
      this.errorMessage.set(null);
      try {
        const importedPalette = this.parseColorsXml(e.target.result);
        if (Object.keys(importedPalette).length === 0) {
          this.errorMessage.set('No valid colors found in the XML file.');
        } else {
          this.palette.update(p => ({ ...p, ...importedPalette }));
        }
      } catch (error) {
        this.errorMessage.set('Failed to parse the XML file.');
      } finally {
        input.value = '';
      }
    };
    reader.readAsText(file);
  }

  private parseColorsXml(xmlContent: string): Partial<ColorPalette> {
    const colorMap: { [key: string]: keyof ColorPalette } = {
      colorPrimary: 'primary',
      colorSecondary: 'secondary',
      colorAccent: 'accent',
      theme_accent: 'accent',
      textColor: 'text',
      widget_text: 'text',
      backgroundColor: 'background',
      theme_background: 'background',
    };
    
    const imported: Partial<ColorPalette> = {};
    const regex = /<color name="([^"]+)">([^<]+)<\/color>/g;
    let match;

    while ((match = regex.exec(xmlContent)) !== null) {
      const name = match[1];
      const value = match[2];
      if (colorMap[name]) {
        imported[colorMap[name]] = value;
      }
    }
    return imported;
  }

  updateColor(key: keyof ColorPalette, event: Event): void {
    const newColor = (event.target as HTMLInputElement).value;
    this.palette.update(p => ({ ...p, [key]: newColor }));
  }
  
  updateThemeMap(role: string, event: Event): void {
    const paletteKey = (event.target as HTMLSelectElement).value as keyof ColorPalette;
    this.themeMap.update(map => ({...map, [role]: paletteKey}));
  }

  setWidgetStyle(style: string): void {
    if (style === 'glass' || style === 'opaque' || style === 'gradient') {
      this.widgetStyle.set(style);
    }
  }

  saveTheme(): void {
    this.themeService.saveTheme({
      wallpaperUrl: this.wallpaperUrl(),
      palette: this.palette(),
      themeMap: this.themeMap(),
    });
  }

  exportTheme(): void {
    const themeJson = JSON.stringify({
      wallpaper: this.wallpaperUrl(),
      colors: this.palette(),
      themeMap: this.themeMap(),
    }, null, 2);
    
    this.downloadFile(themeJson, 'futuristic-theme.json', 'application/json');
  }

  private generateColorsXml(): string {
    const currentPalette = this.palette();
    const currentMap = this.themeMap();
    let xmlContent = `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n`;
    
    for (const role of this.themeRoles) {
      const paletteKey = currentMap[role.key];
      if(paletteKey) {
          const colorValue = currentPalette[paletteKey];
          // Android uses 'android:colorBackground' but in XML it's just 'colorBackground'
          const tagName = role.key.replace('android_', '');
          xmlContent += `    <color name="${tagName}">${colorValue}</color>\n`;
      }
    }
    xmlContent += `</resources>`;
    return xmlContent;
  }

  private generateThemesXml(): string {
    return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Base application theme. -->
    <style name="Theme.App" parent="Theme.MaterialComponents.DayNight.DarkActionBar">
        <!-- Primary brand color. -->
        <item name="colorPrimary">@color/colorPrimary</item>
        <item name="colorOnPrimary">@color/colorOnPrimary</item>
        <!-- Secondary brand color. -->
        <item name="colorSecondary">@color/colorSecondary</item>
        <item name="colorOnSecondary">@color/colorOnSecondary</item>
        <!-- Accent/tertiary color. -->
        <item name="colorAccent">@color/colorAccent</item>
        <!-- Status bar color. -->
        <item name="android:statusBarColor">?attr/colorPrimary</item>
        <!-- Background colors. -->
        <item name="android:colorBackground">@color/colorBackground</item>
        <item name="colorOnBackground">@color/colorOnBackground</item>
        <!-- Surface colors. -->
        <item name="colorSurface">@color/colorSurface</item>
        <item name="colorOnSurface">@color/colorOnSurface</item>
    </style>
</resources>`;
  }

  private generateGradientDrawableXml(): string {
    const p = this.palette();
    return `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <gradient
        android:type="linear"
        android:angle="135"
        android:startColor="${p.primary}"
        android:endColor="${p.secondary}" />
</shape>`;
  }
  
  private generateClockWidgetInfoXml(): string {
    return `<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android"
    android:minWidth="180dp"
    android:minHeight="72dp"
    android:updatePeriodMillis="0"
    android:initialLayout="@layout/widget_clock"
    android:resizeMode="horizontal|vertical"
    android:widgetCategory="home_screen" />`;
  }

  private generateWeatherWidgetInfoXml(): string {
    return `<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android"
    android:minWidth="110dp"
    android:minHeight="110dp"
    android:updatePeriodMillis="3600000"
    android:initialLayout="@layout/widget_weather"
    android:resizeMode="horizontal|vertical"
    android:widgetCategory="home_screen" />`;
  }
  
  private generateCalendarWidgetInfoXml(): string {
    return `<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android"
    android:minWidth="110dp"
    android:minHeight="110dp"
    android:updatePeriodMillis="0"
    android:initialLayout="@layout/widget_calendar"
    android:resizeMode="horizontal|vertical"
    android:widgetCategory="home_screen" />`;
  }
  
  private generateMusicWidgetInfoXml(): string {
    return `<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android"
    android:minWidth="180dp"
    android:minHeight="72dp"
    android:updatePeriodMillis="0"
    android:initialLayout="@layout/widget_music"
    android:resizeMode="horizontal|vertical"
    android:widgetCategory="home_screen" />`;
  }

  exportMappedColorsXml(): void {
    const xmlContent = this.generateColorsXml();
    this.downloadFile(xmlContent, 'colors.xml', 'application/xml');
  }

  exportThemesXml(): void {
    const xmlContent = this.generateThemesXml();
    this.downloadFile(xmlContent, 'themes.xml', 'application/xml');
  }

  exportGradientDrawableXml(): void {
    const xmlContent = this.generateGradientDrawableXml();
    this.downloadFile(xmlContent, 'theme_gradient_drawable.xml', 'application/xml');
  }
  
  exportClockWidgetInfoXml(): void {
    const xmlContent = this.generateClockWidgetInfoXml();
    this.downloadFile(xmlContent, 'clock_widget_info.xml', 'application/xml');
  }

  exportWeatherWidgetInfoXml(): void {
    const xmlContent = this.generateWeatherWidgetInfoXml();
    this.downloadFile(xmlContent, 'weather_widget_info.xml', 'application/xml');
  }

  exportCalendarWidgetInfoXml(): void {
    const xmlContent = this.generateCalendarWidgetInfoXml();
    this.downloadFile(xmlContent, 'calendar_widget_info.xml', 'application/xml');
  }

  exportMusicWidgetInfoXml(): void {
    const xmlContent = this.generateMusicWidgetInfoXml();
    this.downloadFile(xmlContent, 'music_widget_info.xml', 'application/xml');
  }


  async exportThemePackage(): Promise<void> {
    if (typeof JSZip === 'undefined') {
      this.errorMessage.set('Could not create theme package. JSZip library is missing.');
      console.error('JSZip not found. Make sure the library is loaded.');
      return;
    }

    this.isLoading.set(true);
    this.errorMessage.set(null);

    try {
      const zip = new JSZip();

      // Add XML files
      const values = zip.folder('res/values');
      values.file('colors.xml', this.generateColorsXml());
      values.file('themes.xml', this.generateThemesXml());

      const drawable = zip.folder('res/drawable');
      drawable.file('theme_gradient_drawable.xml', this.generateGradientDrawableXml());

      const xml = zip.folder('res/xml');
      xml.file('clock_widget_info.xml', this.generateClockWidgetInfoXml());
      xml.file('weather_widget_info.xml', this.generateWeatherWidgetInfoXml());
      xml.file('calendar_widget_info.xml', this.generateCalendarWidgetInfoXml());
      xml.file('music_widget_info.xml', this.generateMusicWidgetInfoXml());


      // Add wallpaper if it's an uploaded one (data URL)
      const wallpaper = this.wallpaperUrl();
      if (wallpaper.startsWith('data:image')) {
        const match = wallpaper.match(/^data:(image\/(\w+));base64,(.+)$/);
        if (match) {
          const fileExtension = match[2] === 'jpeg' ? 'jpg' : match[2];
          const base64Data = match[3];
          zip.file(`wallpaper.${fileExtension}`, base64Data, { base64: true });
        }
      }

      const content = await zip.generateAsync({ type: 'blob' });
      this.downloadFile(content, 'futuristic-theme.zip');

    } catch (error) {
      console.error('Error creating theme package:', error);
      this.errorMessage.set('An unexpected error occurred while creating the theme package.');
    } finally {
      this.isLoading.set(false);
    }
  }

  private downloadFile(content: string | Blob, fileName: string, mimeType?: string): void {
      const blob = content instanceof Blob ? content : new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
  }

  resetTheme(): void {
    this.themeService.clearTheme();
    this.wallpaperUrl.set(this.defaultWallpaper);
    this.palette.set(this.defaultPalette);
    this.themeMap.set(this.defaultThemeMap);
    this.errorMessage.set(null);
  }
}