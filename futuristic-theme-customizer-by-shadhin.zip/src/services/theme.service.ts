
import { Injectable, signal } from '@angular/core';
import { Theme } from '../models/theme.model';

@Injectable({
  providedIn: 'root',
})
export class ThemeService {
  private readonly storageKey = 'futuristicTheme';

  saveTheme(theme: Theme): void {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(theme));
    } catch (error) {
      console.error('Error saving theme to localStorage', error);
    }
  }

  loadTheme(): Theme | null {
    try {
      const themeJson = localStorage.getItem(this.storageKey);
      if (themeJson) {
        return JSON.parse(themeJson) as Theme;
      }
      return null;
    } catch (error) {
      console.error('Error loading theme from localStorage', error);
      return null;
    }
  }

  clearTheme(): void {
    try {
      localStorage.removeItem(this.storageKey);
    } catch (error) {
      console.error('Error clearing theme from localStorage', error);
    }
  }
}
