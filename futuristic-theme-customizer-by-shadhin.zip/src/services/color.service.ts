import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ColorService {
  /**
   * Converts a hex color string to an RGB object.
   * Supports 3-digit and 6-digit hex codes with an optional '#'.
   */
  private hexToRgb(hex: string): { r: number; g: number; b: number } | null {
    if (!hex || typeof hex !== 'string') {
      return null;
    }

    let processedHex = hex.startsWith('#') ? hex.slice(1) : hex;

    if (processedHex.length === 3) {
      processedHex = processedHex.split('').map(char => char + char).join('');
    }

    if (processedHex.length !== 6) {
      return null;
    }

    const bigint = parseInt(processedHex, 16);
    const r = (bigint >> 16) & 255;
    const g = (bigint >> 8) & 255;
    const b = bigint & 255;

    return { r, g, b };
  }

  /**
   * Calculates the luminance of an RGB color.
   * The formula is based on the WCAG definition for perceived brightness.
   * Returns a value between 0 (black) and 255 (white).
   */
  private getLuminance(r: number, g: number, b: number): number {
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }

  /**
   * Determines whether to use black or white text for a given background hex color.
   * @param hex The background color in hex format.
   * @returns '#000000' (black) for light backgrounds or '#ffffff' (white) for dark backgrounds.
   */
  public getContrastColor(hex: string): string {
    const rgb = this.hexToRgb(hex);
    if (!rgb) {
      return '#000000'; // Default to black for invalid colors
    }

    const luminance = this.getLuminance(rgb.r, rgb.g, rgb.b);
    
    // The threshold 128 is a common choice for sRGB colors (0-255).
    // If luminance is > 128, the color is light, so we use black text.
    // Otherwise, the color is dark, and we use white text.
    return luminance > 128 ? '#000000' : '#ffffff';
  }
}
