export interface ColorPalette {
  primary: string;
  secondary: string;
  accent: string;
  text: string;
  background: string;
}

export type ThemeRoleMap = {
  [key: string]: keyof ColorPalette;
};

export interface Theme {
  wallpaperUrl: string;
  palette: ColorPalette;
  themeMap: ThemeRoleMap;
}
