
import { Injectable } from '@angular/core';
import { GoogleGenAI, Type } from '@google/genai';
import { ColorPalette } from '../models/theme.model';

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // The API key MUST be obtained exclusively from the environment variable `process.env.API_KEY`.
    // This is a hard requirement for the Applet environment.
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      throw new Error("API_KEY environment variable not set.");
    }
    this.ai = new GoogleGenAI({ apiKey });
  }

  async extractColorsFromImage(base64Image: string): Promise<ColorPalette> {
    const imagePart = {
      inlineData: {
        data: base64Image,
        mimeType: 'image/jpeg',
      },
    };

    const prompt = `Analyze this wallpaper image and extract a harmonious, futuristic color palette of 5 colors suitable for a UI theme. The colors should be aesthetically pleasing and work well together. Provide hex color codes. The palette should consist of:
    - primary: A dominant, eye-catching color.
    - secondary: A color that complements the primary color.
    - accent: A bright color for highlights, buttons, and calls to action.
    - text: A color for body text that ensures high readability against the background.
    - background: A color for widget backgrounds that fits the overall theme.`;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [imagePart, { text: prompt }] },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              primary: { type: Type.STRING },
              secondary: { type: Type.STRING },
              accent: { type: Type.STRING },
              text: { type: Type.STRING },
              background: { type: Type.STRING },
            },
            required: ['primary', 'secondary', 'accent', 'text', 'background'],
          },
        },
      });
      
      const jsonText = response.text.trim();
      return JSON.parse(jsonText) as ColorPalette;
    } catch (error) {
      console.error('Error calling Gemini API:', error);
      throw new Error('Failed to generate color palette. Please check your API key and try again.');
    }
  }
}
