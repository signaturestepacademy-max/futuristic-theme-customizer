import { Component, ChangeDetectionStrategy, input, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ColorPalette } from '../../models/theme.model';
import { WidgetStyle } from '../../app.component';

@Component({
  selector: 'app-weather-widget',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (palette(); as p) {
      <div 
        class="w-full h-full p-6 rounded-2xl flex items-center transition-all duration-500"
        [style]="widgetStyles()"
        [style.color]="p.text"
      >
        <div class="text-5xl mr-4" [style.color]="p.accent">
          <!-- Placeholder Cloud Icon -->
          <svg xmlns="http://www.w3.org/2000/svg" class="h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" />
          </svg>
        </div>
        <div>
          <div class="font-orbitron text-4xl font-bold">24°C</div>
          <div class="text-md uppercase tracking-wider" [style.color]="p.secondary">Partly Cloudy</div>
        </div>
      </div>
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class WeatherWidgetComponent {
  palette = input.required<ColorPalette | null>();
  style = input<WidgetStyle>('glass');

  widgetStyles = computed(() => {
    const p = this.palette();
    if (!p) return {};
    
    switch (this.style()) {
      case 'opaque':
        return { backgroundColor: p.background };
      case 'gradient':
        return { backgroundImage: `linear-gradient(to bottom right, ${p.primary}CC, ${p.secondary}CC)` };
      case 'glass':
      default:
        return { 
          backgroundColor: p.background + '80',
          'backdrop-filter': 'blur(10px)',
          '-webkit-backdrop-filter': 'blur(10px)'
        };
    }
  });
}