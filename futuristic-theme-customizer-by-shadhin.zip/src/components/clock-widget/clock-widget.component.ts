import { Component, ChangeDetectionStrategy, input, signal, OnInit, OnDestroy, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ColorPalette } from '../../models/theme.model';
import { WidgetStyle } from '../../app.component';

@Component({
  selector: 'app-clock-widget',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (palette(); as p) {
      <div 
        class="w-full h-full p-6 rounded-2xl flex flex-col justify-center items-center text-center transition-all duration-500"
        [style]="widgetStyles()"
        [style.color]="p.text"
      >
        <div class="font-orbitron text-6xl md:text-7xl font-bold tracking-wider" [style.text-shadow]="'0 0 10px ' + p.accent">
          <span>{{ hours() }}</span>
          <span class="animate-pulse">:</span>
          <span>{{ minutes() }}</span>
        </div>
        <div class="text-lg uppercase tracking-widest mt-2" [style.color]="p.secondary">
          {{ date() }}
        </div>
      </div>
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ClockWidgetComponent implements OnInit, OnDestroy {
  palette = input.required<ColorPalette | null>();
  style = input<WidgetStyle>('glass');

  time = signal(new Date());
  hours = signal('');
  minutes = signal('');
  date = signal('');
  
  private intervalId: any;

  widgetStyles = computed(() => {
    const p = this.palette();
    if (!p) return {};
    
    switch (this.style()) {
      case 'opaque':
        return { backgroundColor: p.background };
      case 'gradient':
        return { backgroundImage: `linear-gradient(to bottom right, ${p.primary}CC, ${p.secondary}CC)` };
      case 'glass':
      default:
        return { 
          backgroundColor: p.background + '80',
          'backdrop-filter': 'blur(10px)',
          '-webkit-backdrop-filter': 'blur(10px)'
        };
    }
  });

  ngOnInit(): void {
    this.updateTime();
    this.intervalId = setInterval(() => {
      this.time.set(new Date());
      this.updateTime();
    }, 1000);
  }

  ngOnDestroy(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  updateTime(): void {
    const now = this.time();
    this.hours.set(now.getHours().toString().padStart(2, '0'));
    this.minutes.set(now.getMinutes().toString().padStart(2, '0'));
    this.date.set(now.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' }));
  }
}