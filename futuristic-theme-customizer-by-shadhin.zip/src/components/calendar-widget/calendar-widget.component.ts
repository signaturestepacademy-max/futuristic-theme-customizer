import { Component, ChangeDetectionStrategy, input, signal, OnInit, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ColorPalette } from '../../models/theme.model';
import { WidgetStyle } from '../../app.component';

@Component({
  selector: 'app-calendar-widget',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (palette(); as p) {
      <div 
        class="w-full h-full p-6 rounded-2xl flex flex-col justify-between transition-all duration-500"
        [style]="widgetStyles()"
        [style.color]="p.text"
      >
        <div>
          <div class="font-orbitron text-2xl font-bold uppercase tracking-wider" [style.color]="p.secondary">
            {{ month() }}
          </div>
          <div class="font-orbitron text-6xl font-extrabold" [style.text-shadow]="'0 0 8px ' + p.accent">
            {{ day() }}
          </div>
        </div>
        <div class="mt-2">
          <h3 class="text-sm uppercase tracking-widest mb-1 opacity-70">Upcoming</h3>
          <div class="text-sm space-y-1">
            <div class="flex items-center">
              <div class="w-1.5 h-1.5 rounded-full mr-2" [style.background-color]="p.accent"></div>
              <span>18:00 - Project Sync</span>
            </div>
            <div class="flex items-center">
              <div class="w-1.5 h-1.5 rounded-full mr-2" [style.background-color]="p.accent"></div>
              <span>20:30 - System Upgrade</span>
            </div>
          </div>
        </div>
      </div>
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CalendarWidgetComponent implements OnInit {
  palette = input.required<ColorPalette | null>();
  style = input<WidgetStyle>('glass');

  month = signal('');
  day = signal('');

  widgetStyles = computed(() => {
    const p = this.palette();
    if (!p) return {};
    
    switch (this.style()) {
      case 'opaque':
        return { backgroundColor: p.background };
      case 'gradient':
        return { backgroundImage: `linear-gradient(to bottom right, ${p.primary}CC, ${p.secondary}CC)` };
      case 'glass':
      default:
        return { 
          backgroundColor: p.background + '80',
          'backdrop-filter': 'blur(10px)',
          '-webkit-backdrop-filter': 'blur(10px)'
        };
    }
  });

  ngOnInit(): void {
    const now = new Date();
    this.month.set(now.toLocaleDateString(undefined, { month: 'long' }));
    this.day.set(now.getDate().toString());
  }
}